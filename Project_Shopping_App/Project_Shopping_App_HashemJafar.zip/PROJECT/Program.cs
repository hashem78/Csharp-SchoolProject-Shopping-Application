﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// Hashem ziad hashem alayan
// Jafar feras jafar aljuneidi
namespace shoppingApp
{
    class Program
    {

        static void Main(string[] args)
        {
            //Admin's username is "admin", password is "00"
            //rest of users are like worksheet
            Login.Menu();
        }
    }
}
